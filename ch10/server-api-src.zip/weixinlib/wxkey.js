module.exports = {
    appid : '',
    secret : ''
};
